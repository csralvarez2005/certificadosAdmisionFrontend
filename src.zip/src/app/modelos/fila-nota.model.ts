export interface FilaNota {
  periodo: string;
  modulo: string;
  nota: string;
}