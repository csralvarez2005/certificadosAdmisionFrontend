import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { switchMap } from 'rxjs/operators';
import { EstudiantePageResponse } from '../modelos/estudiante-page-response.model';

@Injectable({
  providedIn: 'root',
})
export class EstudianteService {
  private baseUrl = 'http://localhost:8080/api/estudiantes';

  constructor(private http: HttpClient) {}

  // Listado paginado de estudiantes
  listarTodosPaginado(page: number, size: number): Observable<EstudiantePageResponse> {
    const url = `${this.baseUrl}/listar?page=${page}&size=${size}`;
    return this.http.get<EstudiantePageResponse>(url);
  }

  // Constancia de estudio estándar (se guarda en BD)
  generarConstancia(estudianteId: number): Observable<Blob> {
    return this.http
      .post<{ id: number }>(`${this.baseUrl}/reporte/constancia-estudio/${estudianteId}`, {})
      .pipe(
        switchMap(res =>
          this.http.get(`${this.baseUrl}/reporte/${res.id}`, {
            responseType: 'blob',
          })
        )
      );
  }

  // Constancia de estudio personalizada (no se guarda en BD)
  generarConstanciaPersonalizada(estudianteId: number, cuerpo: string): Observable<Blob> {
    const url = `${this.baseUrl}/reporte/constancia-estudio/personalizada?id=${estudianteId}`;
    return this.http.post(url, { cuerpo }, { responseType: 'blob' });
  }

  // Constancia de notas por nivel (se guarda en BD)
  generarConstanciaNotas(estudianteId: number, nivel: number): Observable<Blob> {
    const url = `${this.baseUrl}/reporte/constancia-notas/${estudianteId}?nivel=${nivel}`;
    return this.http
      .post<{ id: number }>(url, {})  // POST sin cuerpo, pero necesario por método backend
      .pipe(
        switchMap(res =>
          this.http.get(`${this.baseUrl}/reporte/${res.id}`, {
            responseType: 'blob',
          })
        )
      );
  }
  generarConstanciaNotasPersonalizada(estudianteId: number, nivel: number, cuerpo: string): Observable<Blob> {
  const url = `${this.baseUrl}/reporte/constancia-notas/personalizada?id=${estudianteId}&nivel=${nivel}`;
  return this.http.post(url, { cuerpo }, { responseType: 'blob' });
}
}