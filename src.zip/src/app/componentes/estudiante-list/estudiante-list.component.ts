import { Component, OnInit, Inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { EstudianteService } from '../../servicios/estudiante.service';
import { Estudiante } from '../../modelos/estudiante.model';
import { EstudiantePageResponse } from '../../modelos/estudiante-page-response.model';

import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule, PageEvent } from '@angular/material/paginator';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatDialog, MatDialogModule, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';

@Component({
  selector: 'app-estudiante-list',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    MatTableModule,
    MatPaginatorModule,
    MatCardModule,
    MatIconModule,
    MatButtonModule,
    MatTooltipModule,
    MatDialogModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule
  ],
  templateUrl: './estudiante-list.component.html',
  styleUrls: ['./estudiante-list.component.css'],
})
export class EstudianteListComponent implements OnInit {
  estudiantes: Estudiante[] = [];
  paginaActual = 0;
  totalPaginas = 0;
  elementosPorPagina = 5;
  totalItems = 0;

  displayedColumns: string[] = [
    'nombre',
    'codigo',
    'programa',
    'concepto',
    'fechaLiquidacion',
    'estado',
    'accion',
  ];

  constructor(private estudianteService: EstudianteService, private dialog: MatDialog) {}

  ngOnInit(): void {
    this.cargarEstudiantes();
  }

  cargarEstudiantes(): void {
    this.estudianteService
      .listarTodosPaginado(this.paginaActual, this.elementosPorPagina)
      .subscribe((response: EstudiantePageResponse) => {
        this.estudiantes = response.estudiantes
          .map(est => ({
            ...est,
            fechaLiquidacion: this.parseFecha(est.fechaLiquidacion as unknown as string)
          }))
          .sort((a, b) =>
            a.fechaLiquidacion.getTime() - b.fechaLiquidacion.getTime()
          );

        this.totalItems = response.totalElementos;
        this.totalPaginas = response.totalPaginas;
      });
  }

  onPageChange(event: PageEvent): void {
    this.paginaActual = event.pageIndex;
    this.elementosPorPagina = event.pageSize;
    this.cargarEstudiantes();
  }

  accionEstudiante(est: Estudiante): void {
    switch (est.conceptoFacturacion) {
      case 'CONSTANCIA DE ESTUDIO':
        const cuerpoPorDefecto = this.generarTextoCuerpo(est);
        const cuerpoRef = this.dialog.open(DialogEditarCuerpoComponent, {
          width: '600px',
          data: { cuerpo: cuerpoPorDefecto }
        });

        cuerpoRef.afterClosed().subscribe((textoEditado: string) => {
          if (textoEditado) {
            this.estudianteService.generarConstanciaPersonalizada(est.id, textoEditado)
              .subscribe((pdf: Blob) => {
                this.descargarArchivo(pdf, `constancia_estudio_${est.codigo}.pdf`);
              });
          }
        });
        break;

      case 'CERTIFICADO DE NOTA':
        const nivelRefNota = this.dialog.open(DialogSeleccionarNivelComponent, {
          width: '400px'
        });

        nivelRefNota.afterClosed().subscribe((nivel: number) => {
          if (nivel != null) {
            const cuerpoNota = this.generarTextoCertificadoNotas(est, nivel);

            const cuerpoRefNota = this.dialog.open(DialogEditarCuerpoComponent, {
              width: '600px',
              data: { cuerpo: cuerpoNota }
            });

            cuerpoRefNota.afterClosed().subscribe((textoEditado: string) => {
              if (textoEditado) {
                this.estudianteService
                  .generarConstanciaNotasPersonalizada(est.id, nivel, textoEditado)
                  .subscribe((pdf: Blob) => {
                    this.descargarArchivo(pdf, `certificado_notas_${est.codigo}_nivel${nivel}.pdf`);
                  });
              }
            });
          }
        });
        break;

      case 'CERTIFICADO BUENA CONDUCTA':
        alert('Funcionalidad aún no implementada.');
        break;
    }
  }

  descargarArchivo(blob: Blob, nombreArchivo: string): void {
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = nombreArchivo;
    link.click();
    window.URL.revokeObjectURL(url);
  }

  getTooltip(concepto: string): string {
    switch (concepto) {
      case 'CONSTANCIA DE ESTUDIO':
        return 'Generar constancia de estudio';
      case 'CERTIFICADO DE NOTA':
        return 'Generar certificado de notas';
      case 'CERTIFICADO BUENA CONDUCTA':
        return 'Generar certificado de buena conducta';
      default:
        return 'Acción';
    }
  }

  parseFecha(fecha: string): Date {
    const partes = fecha.split('/');
    const dia = parseInt(partes[0], 10);
    const mes = parseInt(partes[1], 10) - 1;
    const anio = parseInt(partes[2], 10);
    return new Date(anio, mes, dia);
  }

  generarTextoCuerpo(est: Estudiante): string {
    return `Que: ${est.estudiante.toUpperCase()}, identificado(a) con ${est.tipoDocumento.toUpperCase()} ${est.codigo.toUpperCase()}, se encuentra matriculado(a) en esta Fundación para el segundo semestre del programa Técnico laboral en ${est.programaTecnico}. Con Jornada ${est.horario.toLowerCase()}. Periodo B 2025.

Inicio de semestre: 01 de julio 2025               Finalización: 4 de diciembre 2025

Duración de programa: 2 años
Intensidad horaria del programa: 1.248 horas
Intensidad horaria semanal: 24 horas`;
  }

  generarTextoCertificadoNotas(est: Estudiante, nivel: number): string {
    return `Que: ${est.estudiante.toUpperCase()}, identificado(a) con ${est.tipoDocumento.toUpperCase()} ${est.codigo.toUpperCase()}, cursó y aprobó el nivel ${nivel} del programa Técnico laboral en ${est.programaTecnico}, en la jornada ${est.horario.toLowerCase()} correspondiente al segundo semestre del año 2025.

Periodo académico: julio a diciembre de 2025.

Nota definitiva: ${est.notaDefinitiva ?? 'N/A'}`;
  }
}

// ---------- MODAL 1: Editar cuerpo constancia ----------
@Component({
  selector: 'dialog-editar-cuerpo',
  standalone: true,
  imports: [CommonModule, FormsModule, MatDialogModule, MatFormFieldModule, MatInputModule, MatButtonModule],
  template: `
    <h2 mat-dialog-title>Editar cuerpo del certificado</h2>
    <mat-dialog-content>
      <mat-form-field class="w-full">
        <textarea matInput [(ngModel)]="data.cuerpo" rows="10"></textarea>
      </mat-form-field>
    </mat-dialog-content>
    <mat-dialog-actions align="end">
      <button mat-button (click)="ref.close()">Cancelar</button>
      <button mat-button color="primary" (click)="ref.close(data.cuerpo)">Aceptar</button>
    </mat-dialog-actions>
  `,
  styles: [`.w-full { width: 100%; }`]
})
export class DialogEditarCuerpoComponent {
  constructor(
    public ref: MatDialogRef<DialogEditarCuerpoComponent>,
    @Inject(MAT_DIALOG_DATA) public data: { cuerpo: string }
  ) {}
}

// ---------- MODAL 2: Seleccionar nivel ----------
@Component({
  selector: 'dialog-seleccionar-nivel',
  standalone: true,
  imports: [CommonModule, FormsModule, MatDialogModule, MatFormFieldModule, MatSelectModule, MatButtonModule],
  template: `
    <h2 mat-dialog-title>Seleccionar nivel</h2>
    <mat-dialog-content>
      <mat-form-field class="w-full">
        <mat-label>Nivel</mat-label>
        <mat-select [(ngModel)]="nivelSeleccionado">
          <mat-option *ngFor="let n of niveles" [value]="n">{{ n }}</mat-option>
        </mat-select>
      </mat-form-field>
    </mat-dialog-content>
    <mat-dialog-actions align="end">
      <button mat-button (click)="ref.close()">Cancelar</button>
      <button mat-button color="primary" (click)="ref.close(nivelSeleccionado)">Aceptar</button>
    </mat-dialog-actions>
  `,
  styles: [`.w-full { width: 100%; }`]
})
export class DialogSeleccionarNivelComponent {
  niveles = [1, 2, 3, 4, 5, 6];
  nivelSeleccionado!: number;

  constructor(public ref: MatDialogRef<DialogSeleccionarNivelComponent>) {}
}